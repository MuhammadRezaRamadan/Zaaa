<?php
    header("Location: mahasiswa");
    die();
?>